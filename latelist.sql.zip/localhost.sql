-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 10, 2019 at 08:08 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `latelist`
--
CREATE DATABASE IF NOT EXISTS `latelist` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `latelist`;

-- --------------------------------------------------------

--
-- Table structure for table `spots`
--

CREATE TABLE `spots` (
  `id` int(10) NOT NULL,
  `spot_username` varchar(255) NOT NULL,
  `spot_title` varchar(255) NOT NULL,
  `spot_address` varchar(255) NOT NULL,
  `spot_locale` varchar(255) NOT NULL,
  `spot_description` varchar(1024) NOT NULL,
  `spot_lat` text NOT NULL,
  `spot_long` text NOT NULL,
  `image` varchar(1024) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `spots`
--

INSERT INTO `spots` (`id`, `spot_username`, `spot_title`, `spot_address`, `spot_locale`, `spot_description`, `spot_lat`, `spot_long`, `image`) VALUES
(2, 'starbucks', 'Starbucks', '1500 Broadway, New York, NY', 'Coffee Shop', 'Across from the Hilton Hotel', '-73.985703', '40.756779', 'starbucks.png'),
(3, 'dunkindonuts', 'Dunkin Donuts', '100 US-46, Budd Lake, NJ 07828', 'Donuts', 'Small parking lot, not busy after 2AM.', '40.887116', '-74.726652', 'dunkindonuts.png'),
(4, 'walmart', 'Wal-Mart', '1310 Texas Blvd N, Weslaco, TX 78599', 'Retail store', 'Many departments are closed 10PM-10AM', '26.17339', '-97.99088', 'walmart.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `spots`
--
ALTER TABLE `spots`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `spots`
--
ALTER TABLE `spots`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
